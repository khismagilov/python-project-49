from brain_games.games.brain_calc import calculator_game


def main():
    calculator_game()


if __name__ == '__main__':
    main()

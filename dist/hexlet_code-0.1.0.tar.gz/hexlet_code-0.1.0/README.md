### Hexlet tests and linter status:
[![Actions Status](https://github.com/khismagilov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/khismagilov/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/0a7a9225096dd45a2679/maintainability)](https://codeclimate.com/github/khismagilov/python-project-49/maintainability)

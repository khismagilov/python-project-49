### Hexlet tests and linter status:
[![Actions Status](https://github.com/khismagilov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/khismagilov/python-project-49/actions)
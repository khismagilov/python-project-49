### Hexlet tests and linter status:
[![Actions Status](https://github.com/khismagilov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/khismagilov/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/0a7a9225096dd45a2679/maintainability)](https://codeclimate.com/github/khismagilov/python-project-49/maintainability)
[![asciicast](https://asciinema.org/a/GvOG1ZYQTH4gM1XW8XyhUGH8N.svg)](https://asciinema.org/a/GvOG1ZYQTH4gM1XW8XyhUGH8N)
[![asciicast](https://asciinema.org/a/fqyF3j5Dotj8ExZvGii8aZYDe.svg)](https://asciinema.org/a/fqyF3j5Dotj8ExZvGii8aZYDe)
[![asciicast](https://asciinema.org/a/icYPHp2A88EmFfrcrWrwaSHxW.svg)](https://asciinema.org/a/icYPHp2A88EmFfrcrWrwaSHxW)
